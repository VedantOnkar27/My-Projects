drop database student_36;
create database student_36;
use student_36;
create table student(student_id int, student_name varchar(20));
alter table student add column age int, add column phone_no int;
alter table student change student_name sname varchar(20);
alter table student add column class varchar(20) after sname;
alter table student modify sname varchar(30);
alter table student add primary key (student_id);
alter table student add unique key (sname);
insert into student values(1, "Sanjay", "symca", 23, 242543);
insert into student values(2, "Vaidehi", "fymca", 24, 454354);
insert into student values(3, "Akshata", "symca", 21, 543543);
insert into student values(4, "Vidula", "fymca", 22, 435454);
insert into student values(5, "Pratik", "symca", 23, 345435);
update student set age = 22 where sname = "Akshata";
delete from student where sname = "Pratik";
drop user XYZ;
create user XYZ identified by 'XYZ@003';
grant insert, update, delete, select on student_36.student to XYZ;
create table marks(sid int, subject1 int, subject2 int, subject3 int);
alter table marks add foreign key (sid) references student(student_id);
alter table marks add constraint check (subject3>=0);
insert into marks (sid, subject1, subject2, subject3) 
values 
(1,89,78,89), 
(3,99,67,56), 
(4,90,66,45); 
select * from marks;
select * from student;
insert into marks values (6,89,88,88);

