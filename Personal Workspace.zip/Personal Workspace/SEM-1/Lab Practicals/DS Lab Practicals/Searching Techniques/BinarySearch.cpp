 #include <iostream>
using namespace std;

int main() {
    int num = 10, key, choice;
    int arr[10] = {1, 3, 5, 7, 9, 11, 13, 15, 17, 19};

    do {
        int pos = -1;
        int low = 0, high = num - 1, mid;

        cout << "Enter the value to search for: ";
        cin >> key;

        while (low <= high) {
            mid = (low + high) / 2;
            if (key == arr[mid]) {
                pos = mid;
                break;
            } else if (key < arr[mid]) {
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        if (pos == -1) {
            cout << "Element " << key << " not found." << endl;
        } else {
            cout << "Element " << key << " found at position " << pos << "." << endl;
        }

        cout << "Type '1' to search again or '0' to exit: ";
        cin >> choice;

    } while (choice == 1);

    return 0;
}
