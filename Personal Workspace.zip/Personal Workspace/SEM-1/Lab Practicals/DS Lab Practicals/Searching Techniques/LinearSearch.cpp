#include <iostream>
using namespace std;

int main() {
    int arr[10] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20};
    int key, choice;

    do{
       int pos=-1;
    cout << "Enter the value to search for: ";
    cin >> key;
    for (int i = 0; i < 10; i++) {
        if (arr[i] == key) {
            pos = i;
            break;
        }
    }

    if (pos == -1) {
        cout << "Element " << key << " not found." << endl;
    } else {
        cout << "Element " << key << " found at position " << pos << "." << endl;
    }
    cout<<"Enter '1' to search again or enter '0' to exit. \n";
    cin>>choice; 
    }
    while(choice==1);

    return 0;
}
