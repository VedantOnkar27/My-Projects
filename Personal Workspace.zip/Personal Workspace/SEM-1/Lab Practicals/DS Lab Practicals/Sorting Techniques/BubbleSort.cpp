#include <iostream>
#include <cstdlib>
using namespace std;
const int max_size = 100;

class Initialise
{
public:
    int n;
    int arr[max_size];
    void input();
    void bubblesort();
};
void Initialise::input()
{
    cout << "Enter the number of elements in your array: ";
    cin >> n;
    if (n > max_size)
    {
        cout << "The array cannot exceed " << max_size << " elements.\n";
        exit(0);
    }
    cout << "Enter the array elements one by one: ";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
}
void Initialise::bubblesort()
{
    cout<<"Passes: \n";
    int temp;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
        for(int i=0; i<n ; i++) //To display passes
            {
                cout<<arr[i]<<" ";
            }
            cout<<"\n";

    }
    cout << "Bubble-Sorted array: ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}

int main()
{
    int choice;
    Initialise a;
    do
    {
        a.input();
        a.bubblesort();
        cout<<"Press '1' to enter new array and sort it."<<endl<<
        "Press '0' to Exit.";
        cin>>choice;
    }
    while(choice==1);
    
}
