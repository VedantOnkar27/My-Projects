#include <iostream>
#include <cstdlib>
using namespace std;
const int max_size = 100;

class Initialise
{
public:
    int n;
    int arr[max_size];
    void input();
    void bubblesort();
    void selectionsort();
    void insertionsort();
    void quicksort(int low, int high, int count);
    void mergesort(int left, int right, int &count);
    void radixsort(int count);
    void search();
};
void Initialise::input()
{
    cout << "Enter the number of elements in your array: ";
    cin >> n;
    if (n > max_size)
    {
        cout << "The array cannot exceed " << max_size << " elements.\n";
        exit(0);
    }
    cout << "Enter the array elements one by one: ";
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
}
void Initialise::bubblesort() // Reference 1
{
    cout << "Passes: \n";
    int temp, count;
    count = 1;
    for (int i = 0; i < n - 1; i++)
    {
        cout << "Pass " << count << ": ";
        count++;

        for (int j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
        for (int i = 0; i < n; i++) // To display passes
        {
            cout << arr[i] << " ";
        }
        cout << "\n";
    }
    cout << "Bubble-Sorted array: ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
void Initialise::selectionsort() // Reference 2
{
    cout << "Passes: \n";
    int temp, min = 0;
    for (int i = min + 1; i < n; i++)
    {
        if (arr[min] > arr[i])
        {
            temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
        min = i;
        for (int i = 0; i < n; i++) // To display passes
        {
            cout << arr[i] << " ";
        }
        cout << "\n";
    }
    cout << "Selection-Sorted array: ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
void Initialise::insertionsort() // Reference 3
{
    cout << "Passes: \n";
    int temp, i, j, count;
    count = 1;
    for (i = 1; i < n; i++)
    {
        cout << "Pass " << count << ": ";
        count++;
        temp = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > temp)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = temp;
        for (int i = 0; i < n; i++) // To display passes
        {
            cout << arr[i] << " ";
        }
        cout << "\n";
    }
    cout << "Insertion-Sorted array: ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}
void Initialise::quicksort(int low, int high, int count) // Reference 4
{
    if (low >= high)
    {
        return;
    }
    int i, j, temp, pivot;
    pivot = arr[low];
    i = low + 1;
    j = high;
    while (i <= j)
    {
        while (i <= j && pivot >= arr[i])
        {
            i++;
        }
        while (i <= j && pivot < arr[j])
        {
            j--;
        }
        if (i < j)
        {
            temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    arr[low] = arr[j];
    arr[j] = pivot;
    cout << "Pass " << count << ": ";
    for (i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
    count++;
    quicksort(low, j - 1, count);
    quicksort(j + 1, high, count);
}
void Initialise::mergesort(int left, int right, int &count) // Reference 5
{
    if (left < right)
    {
        int mid = (left + right) / 2;
        mergesort(left, mid, count);
        mergesort(mid + 1, right, count);
        int temp[max_size], i, j, k;
        i = left;
        j = mid + 1;
        k = 0;
        while (i <= mid && j <= right)
        {
            if (arr[i] <= arr[j])
            {
                temp[k++] = arr[i++];
            }
            else
            {
                temp[k++] = arr[j++];
            }
        }
        while (i <= mid)
        {
            temp[k++] = arr[i++];
        }
        while (j <= right)
        {
            temp[k++] = arr[j++];
        }
        for (i = left, k = 0; i <= right; i++, k++)
        {
            arr[i] = temp[k];
        }
        cout << "Pass " << count << ": ";
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        count++;
        cout << endl;
    }
}
void Initialise::radixsort(int count) // Reference 6
{
    int max;
    max = arr[0];
    
    for (int i = 1; i < n; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }
    
    for (int div = 1; max / div > 0; div *= 10)
    {
        int out[n];
        int range = 10; 
        int countarr[range];
        
        for (int i = 0; i < range; i++)
        {
            countarr[i] = 0;
        }
        
        for (int i = 0; i < n; i++)
        {
            countarr[(arr[i] / div) % 10]++;
        }
        
        for (int i = 1; i < range; i++)
        {
            countarr[i] += countarr[i - 1];
        }
        
        for (int i = n - 1; i >= 0; i--)
        {
            int digit = (arr[i] / div) % 10;
            out[countarr[digit] - 1] = arr[i];
            countarr[digit]--;
        }
        
        for (int i = 0; i < n; i++)
        {
            arr[i] = out[i];
        }
        
        cout << "Pass " << count << ": ";
        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
        cout << "\n";
        count++;
    }
    cout << "Radix-Sorted Array: ";
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}

void Initialise::search()
{
    // Linear Search
    int key, pos = -1;
    cout << "Enter the value to search for: ";
    cin >> key;
    for (int i = 0; i < 10; i++)
    {
        if (arr[i] == key)
        {
            pos = i;
            break;
        }
    }

    if (pos == -1)
    {
        cout << "Element " << key << " not found." << endl;
    }
    else
    {
        cout << "Element " << key << " found at index: " << pos << endl;
    }
}
int main()
{
    Initialise a;
    int count = 1;
    int choice1, choice2, choice3;
    do
    {
        a.input();
        cout << "Enter sorting method to be used (Reference 1-6): " << endl
             << "1. Bubble Sort" << endl
             << "2. Selection Sort" << endl
             << "3. Insertion Sort" << endl
             << "4. Quick Sort" << endl
             << "5. Merge Sort" << endl
             << "6. Radix Sort" << endl
             << "Your Input: ";
        cin >> choice3;
        switch (choice3) // To switch 1 through 6 references for sorting algorithms
        {
        case 1:
            cout << "Bubble Sort: \n";
            a.bubblesort();
            break;

        case 2:
            cout << "Selection Sort: \n";
            a.selectionsort();
            break;

        case 3:
            cout << "Insertion Sort: \n";
            a.insertionsort();
            break;

        case 4:
            cout << "Quick Sort: \n";
            a.quicksort(0, a.n - 1, 1);
            cout << "Quick-Sorted Array: ";
            for (int i = 0; i < a.n; i++)
            {
                cout << a.arr[i] << " ";
            }
            cout << endl;
            break;

        case 5:
            cout << "Merge Sort: \n";
            a.mergesort(0, a.n - 1, count);
            cout << "Merge-Sorted Array: ";
            for (int i = 0; i < a.n; i++)
            {
                cout << a.arr[i] << " ";
            }
            cout << endl;
            break;

        case 6:
            cout << "Radix Sort: \n";
            a.radixsort(1);
            break;
        }
        cout << "Press '1' to enter a new array and sort it." << endl
             << "Press '2' to perform a search in the entered array." << endl
             << "Press '0' to exit." << endl;
        cin >> choice1;
        if (choice1 == 2)
        {
            do
            {
                a.search();
                cout << "Press '3' to search again." << endl
                     << "Press '1' to Enter a new array." << endl
                     << "Press '0' to exit the program.\n";
                cin >> choice2;
                if (choice2 == 0)
                {
                    cout << "Goodbye!";
                    return 0;
                }
                else if (choice2 == 1)
                {
                    break;
                }
            } while (choice2 == 3);
        }
    } while (choice1 != 0);
    cout << "Goodbye!";
    return 0;
}
