#include <iostream>
#include <cstdlib>
using namespace std;

const int max_size = 1000;

class Hashing
{
public:
    int size, hashvalue;
    int probingMethod;
    void hashfunction();
    void modulo_division(int arr[], int key);
    void mid_square(int arr[], int key);
    void digit_extraction(int arr[], int key);
    void fold_shifting(int arr[], int key);
    void fold_boundary(int arr[], int key);
    void double_hashing(int arr[], int key);
    void probing_choice(int arr[], int key, int index);
    void linear_probing(int arr[], int key, int index);
    void quadratic_probing(int arr[], int key, int index);
    int digit_reverse(int chunk);
    void display(int arr[]);
};
void Hashing::hashfunction()
{
    int hashingMethod;

    cout << "Select Hashing Method: " << endl;
    cout << "1. Modulo Division Hashing" << endl;
    cout << "2. Mid Square Hashing" << endl;
    cout << "3. Digit Extraction Hashing" << endl;
    cout << "4. Fold Shifting Hashing" << endl;
    cout << "5. Fold Boundary Hashing" << endl;
    cout << "6. Double Hashing" << endl;
    cout << "Hashmethod Input: ";
    cin >> hashingMethod;
    probingMethod = 0;
    cout << "\nEnter the number of allocation slots in the hash table: ";
    cin >> size;

    if (size <= 0 || size > max_size)
    {
        cout << "Invalid size! Please enter a number between 1 and " << max_size << ".\n";
        hashfunction();
        return;
    }

    int hashtable[size];
    for (int i = 0; i < size; i++)
    {
        hashtable[i] = -1;
    }

    int key = -1;
    cout << "\nEnter the key elements one-by-one: " << endl;
    cout << "0. Stop" << endl;
    cout << "1. Display Current Hashtable Values" << endl;
    while (true)
    {
        cout << "--> Key Input: ";
        cin >> key;
        if (key == 0)
        {
            break;
        }
        else if (key == 1)
        {
            display(hashtable);
            cout << endl;
            cout << "--> Key Input after display: ";
            cin >> key;
            if (key == 0)
            {
                break;
            }
        }

        switch (hashingMethod)
        {
        case 1:
            modulo_division(hashtable, key);
            break;

        case 2:
            mid_square(hashtable, key);
            break;

        case 3:
            digit_extraction(hashtable, key);
            break;

        case 4:
            fold_shifting(hashtable, key);
            break;

        case 5:
            fold_boundary(hashtable, key);
            break;

        case 6:
            double_hashing(hashtable, key);
            break;

        default:
            cout << "Invalid hashing method! Please try again." << endl;
            break;
        }
    }

    display(hashtable);
    int choice;
    cout << "\nDo you want to re-enter a new hashing method?" << endl;
    cout << "0. Exit" << endl;
    cout << "1. Re-Enter New Hashmethod" << endl;
    cin >> choice;

    if (choice == 1)
    {
        hashfunction();
    }
}

void Hashing::modulo_division(int arr[], int key)
{
    hashvalue = key % size;
    if (arr[hashvalue] == -1)
    {
        arr[hashvalue] = key;
    }
    else
    {
        probing_choice(arr, key, hashvalue);
    }
}

void Hashing::mid_square(int arr[], int key)
{
    int temp, mid = -1, hashvalue, numDigit = 0, square = key * key;
    temp = square;
    while (temp > 0)
    {
        numDigit++;
        temp = temp / 10;
    }
    temp = square;
    int num[numDigit];
    for (int i = numDigit - 1; i >= 0; i--)
    {
        num[i] = temp % 10;
        temp /= 10;
    }
    temp = square;
    if (numDigit > 2 && numDigit % 2 == 0)
    {
        mid = (numDigit / 2) - 1;
        hashvalue = (num[mid] * 10) + num[mid + 1];
    }
    else if (numDigit > 2 && numDigit % 2 == 1)
    {
        mid = numDigit / 2;
        hashvalue = num[mid];
    }
    if (mid < 0)
    {
        mid = 0;
        hashvalue = (num[mid] * 10) + num[mid + 1];
    }
    hashvalue = hashvalue % size;
    if (arr[hashvalue] == -1)
    {
        arr[hashvalue] = key;
    }
    else
    {
        probing_choice(arr, key, hashvalue);
    }
}

void Hashing::digit_extraction(int arr[], int key)
{
    // 1st, 3rd, 5th digit extraction
    int numDigit = 0, temp = key, n1, n2, n3;
    while (temp > 0)
    {
        numDigit++;
        temp /= 10;
    }
    temp = key;
    if (numDigit < 3)
    {
        hashvalue = temp % 10;
    }
    else if (numDigit >= 3 && numDigit < 5)
    {
        n1 = temp % 10;
        temp /= 100;
        n2 = temp % 10;
        hashvalue = (n2 * 10) + n1;
    }
    else if (numDigit >= 5)
    {
        n1 = temp % 10;
        temp /= 100;
        n2 = temp % 10;
        temp /= 100;
        n3 = temp % 10;
        hashvalue = (n3 * 100) + (n2 * 10) + n1;
    }
    hashvalue = hashvalue % size;
    if (arr[hashvalue] == -1)
    {
        arr[hashvalue] = key;
    }
    else
    {
        probing_choice(arr, key, hashvalue);
    }
}

void Hashing::fold_shifting(int arr[], int key)
{
    int temp = size - 1, sizeDigit = 0, numDigit = 0;
    while (temp > 0)
    {
        sizeDigit++;
        temp /= 10;
    }
    temp = key;
    while (temp > 0)
    {
        numDigit++;
        temp /= 10;
    }
    temp = 1;
    for (int i = 0; i < sizeDigit; i++)
    {
        temp *= 10;
    }
    int temp1 = key;
    int temp2 = temp;
    int sum = 0;
    for (int i = 0; i <= numDigit; i++)
    {
        int chunk = 0;
        chunk = temp1 % temp;
        temp1 /= temp;
        sum += chunk;
    }
    int sumDigit;
    temp=sum;
    while(temp>0)
    {
        sumDigit++;
        temp /= 10;
    }
    if(sumDigit>sizeDigit)
    {
        sum = sum % temp2;
    }
    hashvalue = sum % size;
    if (arr[hashvalue] == -1)
    {
        arr[hashvalue] = key;
    }
    else
    {
        probing_choice(arr, key, hashvalue);
    }
}

void Hashing::fold_boundary(int arr[], int key)
{
   int temp = size - 1, sizeDigit = 0, numDigit = 0;
    while (temp > 0)
    {
        sizeDigit++;
        temp /= 10;
    }
    temp = key;
    while (temp > 0)
    {
        numDigit++;
        temp /= 10;
    }
    temp = 1;
    for (int i = 0; i < sizeDigit; i++)
    {
        temp *= 10;
    }
    int temp1 = key;
    int temp2 = temp;
    int sum = 0;
    int chunkcount=0;
    for (int i = 0; i <= numDigit; i++)
    {
        int chunk;
        chunk = temp1 % temp;
        temp1 /= temp;
        if(chunkcount==0 && sizeDigit>1)
        {
            chunk = digit_reverse(chunk);
        }
        chunkcount++;
        sum += chunk;
    }
    int sumDigit;
    temp=sum;
    while(temp>0)
    {
        sumDigit++;
        temp /= 10;
    }
    if(sumDigit>sizeDigit)
    {
        sum = sum % temp2;
    }
    hashvalue = sum % size;
    if (arr[hashvalue] == -1)
    {
        arr[hashvalue] = key;
    }
    else
    {
        probing_choice(arr, key, hashvalue);
    }
}

void Hashing::double_hashing(int arr[], int key)
{
    int i = 0, hash, hash1;
    hash = key % size;
    hash1 = 1+(key % (size-1));
    while (true)
    {
        hashvalue = (hash + (i * hash1)) % size;
        if (arr[hashvalue] == -1)
        {
            arr[hashvalue] = key;
            break;
        }
        i++;
    }
}

void Hashing::probing_choice(int arr[], int key, int index)
{
    if (probingMethod == 0)
    {
        cout << "Collision occurred for key " << key << ".\n";
        cout << "Select Probing Method: " << endl;
        cout << "1. Linear Probing" << endl;
        cout << "2. Quadratic Probing" << endl;
        cout << "Probing Input: ";
        cin >> probingMethod;
    }
    if (probingMethod == 1)
    {
        linear_probing(arr, key, hashvalue);
    }
    else if (probingMethod == 2)
    {
        quadratic_probing(arr, key, hashvalue);
    }
}

void Hashing::linear_probing(int arr[], int key, int index)
{
    int i = 1;
    while (true)
    {
        int newIndex = (index + i) % size;
        if (arr[newIndex] == -1)
        {
            arr[newIndex] = key;
            break;
        }
        i++;
    }
}

void Hashing::quadratic_probing(int arr[], int key, int index)
{
    for (int i = 1; i < size; i++)
    {
        int newIndex = (index + i * i) % size;
        if (arr[newIndex] == -1)
        {
            arr[newIndex] = key;
            break;
        }
    }
}

int Hashing::digit_reverse(int chunk)
{
    int inverted = 0;
    while(chunk > 0)
    {
        int digit = chunk % 10;
        inverted = inverted * 10 + digit;
        chunk /= 10;
    }
    return inverted;
}

void Hashing::display(int arr[])
{
    cout << "\nHash Table:\n";
    for (int i = 0; i < size; i++)
    {
        cout << "[" << i << "] ";
        if (arr[i] != -1)
        {
            cout << arr[i] << "\n";
        }
        else
        {
            cout << "[Empty]\n";
        }
    }
}

int main()
{
    Hashing hash;
    hash.hashfunction();
    return 0;
}
