//Quick Sort
#include<iostream>
using namespace std;
int main()
{
    int n, temp;
    cout << "Enter the number of elements in the array: ";
    cin >> n;
    cout << "\n";
    int arr[n], i, low, high, left, right, pivot;
    cout << "Enter the elements in the array:\n";
    for (i = 0; i < n; i++)
        {
            cout << "Element " << i + 1 << ": ";
            cin >> arr[i];
            cout << "\n";
        }
        while(low < high)
        {
            pivot = arr[low];
            left = low + 1;
            right = high;
            while(left <= right)
            {
                //increase left till an element greater than arr[left] is found
                    if(arr[pivot] >= arr[left])
                    {
                        left++;
                    }
                //decrease right till an element lesser than arr[right] is found
                    if(arr[pivot] < arr[right])
                    {
                        right--;
                    }
                //considering if left does not pass right, we need to swap their values
                    if(left < right)
                    {
                        temp = arr[left];
                        arr[left] = arr[right];
                        arr[right] = temp;
                    }
            }
            //replacing pivot in correct position after a pass completes
            temp = pivot;
            pivot = arr[left];
            arr[left] = temp;
        }
        for (i = 0; i < n; i++)
    {
        cout << "Array element " << i + 1 << " is: " << arr[i] << "\n";
    }
    return 0;
}
