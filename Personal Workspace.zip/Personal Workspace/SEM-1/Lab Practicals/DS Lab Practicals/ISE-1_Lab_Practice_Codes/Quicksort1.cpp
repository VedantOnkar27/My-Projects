#include <iostream>
using namespace std;

int main() {
    int n;

    // Ask user for the number of elements
    cout << "Enter the number of elements in the array: ";
    cin >> n;

    // Declare a static array of maximum size
    int arr[n]; // Assume the maximum size of the array is 100

    // Ask user for the array elements
    cout << "Enter the elements of the array:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
      // Output the sorted array

    int low = 0;
    int high = n - 1;

    while (low < high) {
        int pivot = arr[low]; // Choose the pivot
        int left = low + 1;   // Start from the next element
        int right = high;

        while (left <= right) {
            // Move the left pointer to the right if less than or equal to pivot
            if (arr[left] <= pivot) {
                left++; 
            }

            // Move the right pointer to the left if greater than pivot
            if (arr[right] > pivot) {
                right--; 
            }

            // Swap elements if left < right
            if (left < right) {
                int temp = arr[left];
                arr[left] = arr[right];
                arr[right] = temp;
            }
        }

        // Place the pivot in its correct position
        int temp = arr[low];
        arr[low] = arr[right]; // Swap pivot with arr[right]
        arr[right] = temp;

        // Adjust low and high based on pivot position
        if (right - 1 > low) {
            high = right - 1;  // Sort the left side
        }
        if (right + 1 < high) {
            low = right + 1;   // Sort the right side
        }
    }

    // Output the sorted array
    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
