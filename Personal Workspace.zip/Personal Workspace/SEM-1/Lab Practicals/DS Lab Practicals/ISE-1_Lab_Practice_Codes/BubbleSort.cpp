// Bubble Sort
#include <iostream>
using namespace std;
int main()
{
    int n, temp;
    cout << "Enter the number of elements in the array: ";
    cin >> n;
    cout << "\n";
    int arr[n], i ,j;
    cout << "Enter the elements in the array:\n";
    for (i = 0; i < n; i++)
        {
            cout << "Element " << i + 1 << ": ";
            cin >> arr[i];
            cout << "\n";
        }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    for (i = 0; i < n; i++)
    {
        cout << "Array element " << i + 1 << " is: " << arr[i] << "\n";
    }
    return 0;
}