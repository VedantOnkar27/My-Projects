#include <iostream>

using namespace std;

int partition(int arr[], int low, int high) {
    int pivot = arr[low];
    int i = low - 1;

    for (int j = low + 1; j <= high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[low]);
    return i + 1;
}

void iterativeQuickSort(int arr[], int low, int high) {
    int stack[high - low + 1];
    int top = -1;

    stack[++top] = low;
    stack[++top] = high;

    while (top >= 0) {
        high = stack[top--];
        low = stack[top--];

        if (high - low > 1) {
            int pi = partition(arr, low, high);

            stack[++top] = low;
            stack[++top] = pi - 1;

            stack[++top] = pi + 1;
            stack[++top] = high;
        }
    }
}

int main() {
    int arr[] = {10, 7, 8, 9, 1, 5};
    int n = sizeof(arr) / sizeof(arr[0]);

    iterativeQuickSort(arr, 0, n - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < n; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}