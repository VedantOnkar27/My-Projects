#include <iostream>
using namespace std;
int key; 
struct node
{
    int data;
    node* next;
};
node* p;
node* q;
node* list=NULL;
class SinglyLinkedList
{
private:
public:
void input();
void display();
};
void SinglyLinkedList::input()
{
    cout << "Enter Elements in the Linked List: ";
    cin >> key;
    

}
void SinglyLinkedList::display()
{
    for (q = list; q != NULL; q = q -> next)
    {
        
    }
}

int main()
{
    SinglyLinkedList l1;
    l1.input();
    l1.display();
    return 0;
}